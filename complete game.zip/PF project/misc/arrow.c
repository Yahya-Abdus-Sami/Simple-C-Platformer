#include "raylib.h"
#include <math.h>
#define playerspeed 6.0f

int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 800;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "Please give me full weightage for this :)");

    SetTargetFPS(60);               // Set our game to run at 60 frames-per-second
    Vector2 player;
    player.x=400;
    player.y=225;
    Color playerColor={0, 28, 66, 255};
    //starting page
    while (!WindowShouldClose()){
        BeginDrawing();
            ClearBackground(RAYWHITE);
            DrawText("PRESS ARROW KEYS TO START", 190, 200, 20,BLACK);
        EndDrawing();
        
        if(IsKeyPressed(KEY_UP)){
            break;
        }
        if(IsKeyPressed(KEY_RIGHT)){
            break;
        }
        if(IsKeyPressed(KEY_LEFT)){
            break;
        }
    }
    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update variables
        if(IsKeyDown(KEY_DOWN)){
            if(player.y<screenHeight-20)
            player.y+=playerspeed;
        }
        if(IsKeyDown(KEY_UP)){
            if(player.y>20)
            player.y-=playerspeed;
        }
        if(IsKeyDown(KEY_RIGHT)){
            if(player.x<screenWidth-20)
            player.x+=playerspeed;
        }
        if(IsKeyDown(KEY_LEFT)){
            if(player.x>20)
            player.x-=playerspeed;
        }
        // Draw
        BeginDrawing();
            ClearBackground(RAYWHITE);
            DrawText("USE ARROW KEYS", 190, 200, 20, LIGHTGRAY);
            DrawCircle(player.x,player.y,20,playerColor);
        EndDrawing();
        
    }
    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();      
    
    return 0;
}