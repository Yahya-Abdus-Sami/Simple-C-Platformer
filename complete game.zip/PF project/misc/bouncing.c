#include "raylib.h"
#include <math.h>


int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 800;
    const int screenHeight = 450;

    InitWindow(screenWidth, screenHeight, "Please give me full weightage for this :)");

    SetTargetFPS(60);               // Set our game to run at 60 frames-per-second
    Vector2 player,playerspeed={7.0f,-6.0f};
    player.x=400;
    player.y=225;
    Color playerColor={0, 28, 66, 255};
    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update variables
        //movments
        player.y+=playerspeed.y;
        player.x+=playerspeed.x;
        //if(playerspeed.y<10.0f)
        playerspeed.y+=0.3f;

        if(player.x<=20 || player.x>=780){
                playerspeed.x *=-1;
        }
        if(player.y>=430){
            player.y=430;
            playerspeed.y*=-0.93f;
            if (fabs(playerspeed.y)<0.1f){
                playerspeed.y=0.0f;
            }
        }
        
        

    
        // Draw
        BeginDrawing();
            ClearBackground(RAYWHITE);
            DrawText("USE ARROW KEYS", 190, 200, 20, LIGHTGRAY);
            DrawCircle(player.x,player.y,20,playerColor);
        EndDrawing();
        
    }
    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();      
    
    return 0;
}